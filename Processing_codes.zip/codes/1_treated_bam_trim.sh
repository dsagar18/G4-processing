for  i in {1..22}
do
	samtools view -b ERR375896_sorted.bam "chr$i" > "chr$i"_treated_reads.bam
done

for  i in X Y
do
	samtools view -b ERR375896_sorted.bam "chr$i" > "chr$i"_treated_reads.bam
done



