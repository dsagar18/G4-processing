for i in X Y
do
	awk 'BEGIN{count=0;FS="\t";OFS="\t";}
	{
	if($3==0)
	{
        	count++;
	        ep=$2;
	}
	else
	{       
        	if(count>=1000)
        	{
                	print ep-count+1,ep,count;
                	count=0;
        	}
        	else    
        	{       	
			(count=0);
        	}
	}}' "chr$i"_results.tsv > "chr$i"_stats.txt
done

for i in {1..22}
do
	awk 'BEGIN{count=0;FS="\t";OFS="\t";}
	{
	if($3==0)
	{
        	count++;
	        ep=$2;
	}
	else
	{       
        	if(count>=1000)
        	{
                	print ep-count+1,ep,count;
                	count=0;
        	}
        	else    
        	{       	
			(count=0);
        	}
	}}' "chr$i"_results.tsv > "chr$i"_stats.txt
done
