for i in {1..22}
do
	bedtools genomecov -d -ibam "chr$i"_treated_reads.bam -g "chr$i".genome > "chr$i"_results.tsv
done
for i in X Y
do
	bedtools genomecov -d -ibam "chr$i"_treated_reads.bam -g "chr$i".genome > "chr$i"_results.tsv
done
