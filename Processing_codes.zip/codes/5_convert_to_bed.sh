for i in {1..22} 
do 
	awk -v FS="\t" -v OFS="\t" -v chrnum="chr$i" '{print chrnum,$1,$2}' "chr$i"_stats.txt > "chr$i"_treated.bed
done
for i in X Y  
do 
	awk -v FS="\t" -v OFS="\t" -v chrnum="chr$i" '{print chrnum,$1,$2}' "chr$i"_stats.txt > "chr$i"_treated.bed
done
