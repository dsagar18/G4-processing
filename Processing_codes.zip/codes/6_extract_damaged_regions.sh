for i in X Y
do
	coverageBed -abam "chr$i"_reads_sorted_control.bam -b "chr$i"_treated.bed > "chr$i"_unprotected_regions.tsv
done
for i in {1..22}
do
	coverageBed -abam "chr$i"_reads_sorted_control.bam -b "chr$i"_treated.bed> "chr$i"_unprotected_regions.tsv
done
