for i in {1..22}
do	
	awk -v FS="\t" -v OFS="\t" '{if($4>=5){print $1,$2,$3}}' "chr$i"_unprotected_regions.tsv > "chr$i"_unprotected_filtered.bed
done
for i in X Y
do	
	awk -v FS="\t" -v OFS="\t" '{if($4>=5){print $1,$2,$3}}' "chr$i"_unprotected_regions.tsv > "chr$i"_unprotected_filtered.bed
done
